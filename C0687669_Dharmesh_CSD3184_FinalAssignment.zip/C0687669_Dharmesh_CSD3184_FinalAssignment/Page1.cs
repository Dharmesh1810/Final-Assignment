﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace finalapp
{
    [Activity(Label = "page1")]
    public class Page1 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Main);

            Button showPopupMenu = FindViewById<Button>(Resource.Id.popupButton);

            showPopupMenu.Click += delegate
            {

                PopupMenu menu = new PopupMenu(this, showPopupMenu);
                menu.Inflate(Resource.Menu.popup_menu);

                menu.MenuItemClick += (s1, e1) =>
                {

                    switch (e1.Item.TitleFormatted.ToString())
                    {
                        case "Visited Destinations":
                            StartActivity(typeof(Listview1));
                            break;
                        case "Future Destinations":
                            StartActivity(typeof(Listview2));
                            break;
                        case "Contact Me":
                            StartActivity(typeof(Contact));
                            break;

                    }
                };

                menu.Show();

            };
        }
    }
}