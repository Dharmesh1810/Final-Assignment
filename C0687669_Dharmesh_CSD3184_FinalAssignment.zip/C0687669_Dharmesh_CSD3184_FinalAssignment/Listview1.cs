﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace finalapp
{
    [Activity(Label = "Listview1")]
    public class Listview1 : Activity
    {
        List<TableItem> tableItems = new List<TableItem>();
        ListView listView;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.BlogAuthorDescription);

            listView = FindViewById<ListView>(Resource.Id.countryList);

            tableItems.Add(new TableItem() { Heading = "Seattle", ImageResourceId = Resource.Drawable.seattle.jpg });
            tableItems.Add(new TableItem() { Heading = "Miami", ImageResourceId = Resource.Drawable.Miami.jpg });
            tableItems.Add(new TableItem() { Heading = "San Diego", ImageResourceId = Resource.Drawable.SanDiego.jpg });
            tableItems.Add(new TableItem() { Heading = "New York", ImageResourceId = Resource.Drawable.NewYork.jpg });
            tableItems.Add(new TableItem() { Heading = "Lake Charles", ImageResourceId = Resource.Drawable.LakeCharles.jpg });

            listView.Adapter = new HomeScreenAdapter(this, tableItems);

            listView.ItemClick += OnListItemClick;
        }

        protected void OnListItemClick(object sender, Android.Widget.AdapterView.ItemClickEventArgs e)
        {
            var listView = sender as ListView;
            var t = tableItems[e.Position];

        }
    }
}

